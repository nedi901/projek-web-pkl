# Paket: Sampah → Histori + perbaikan jam (WIB)

Path relatif terhadap root project. Pasang SETELAH paket-paket sebelumnya (termasuk format-angka-package).

## 1. Rename Sampah → Histori
- Menu sidebar: "Sampah Batubara" → **"Histori"** (tanpa nama domain, di semua domain)
- Judul halaman "Sampah — X" → **"Histori"** (dan "Log Aktivitas", tanpa nama domain)
- Tombol "Riwayat Aktivitas" → **"Log Aktivitas"** (supaya tidak tertukar dengan Histori)
- URL: `/admin/batubara/sampah` → `/admin/batubara/histori`, `/sampah/riwayat` → `/histori/log`
- Route name: `admin.<domain>.sampah.*` → `admin.<domain>.histori.*` (riwayat → log)
- Controller `SampahController` → `HistoriController`; view `admin/sampah/*` → `admin/histori/*`

### WAJIB hapus file lama (sudah tidak dipakai)
- `app/Http/Controllers/Admin/SampahController.php`
- folder `resources/views/admin/sampah/`

Lalu: `php artisan optimize:clear` dan cek `php artisan route:list --name=histori`.
(Tabel database `riwayat_data` tidak berubah, jadi data log lama tetap aman.)

## 2. Jam salah (03:04 padahal 10:04)
Penyebabnya bukan data rusak: Laravel menyimpan waktu dalam UTC (selisih 7 jam dari WIB).
Sekarang tampilan di halaman Histori & Log Aktivitas dikonversi ke WIB dan diberi label "WIB", bulan berbahasa Indonesia
(mis. "01 Okt 2026, 10:04 WIB"). Data lama dan baru sama-sama benar, tidak perlu migrasi.
